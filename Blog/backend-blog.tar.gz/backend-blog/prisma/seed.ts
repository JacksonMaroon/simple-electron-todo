// Database seed script
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Create a test admin user
  const adminPassword = await bcrypt.hash('adminpassword', 10);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: {
      email: 'admin@example.com',
      hash: adminPassword,
      role: 'ADMIN'
    }
  });
  console.log(`Created admin user: ${admin.email}`);

  // Create some tags
  const tagTech = await prisma.tag.upsert({
    where: { name: 'Technology' },
    update: {},
    create: {
      name: 'Technology',
      color: '#3498db'
    }
  });

  const tagPhilosophy = await prisma.tag.upsert({
    where: { name: 'Philosophy' },
    update: {},
    create: {
      name: 'Philosophy',
      color: '#9b59b6'
    }
  });

  console.log(`Created tags: ${tagTech.name}, ${tagPhilosophy.name}`);

  // Create a demo series
  const demoSeries = await prisma.series.upsert({
    where: { title: 'Demo Series' },
    update: {},
    create: {
      title: 'Demo Series',
      description: 'A series of demo posts',
      order: JSON.stringify([]) // Will update this after creating posts
    }
  });

  // Create some demo posts
  const demoPost1 = await prisma.post.upsert({
    where: { slug: 'welcome-to-my-blog' },
    update: {},
    create: {
      title: 'Welcome to My Blog',
      slug: 'welcome-to-my-blog',
      contentMDX: `
# Welcome to My Blog

This is a demo post to showcase the capabilities of this blog platform.

## Features

- MDX support for interactive content
- Tagging system
- Series for grouped content
- Comments and reactions

\`\`\`js
// Even code blocks work!
function hello() {
  console.log("Hello, World!");
}
\`\`\`
      `,
      summary: 'Introduction to my new blog platform',
      status: 'PUBLISHED',
      publishedAt: new Date(),
      seriesId: demoSeries.id
    }
  });

  const demoPost2 = await prisma.post.upsert({
    where: { slug: 'deep-dive-into-philosophy' },
    update: {},
    create: {
      title: 'A Deep Dive into Philosophy',
      slug: 'deep-dive-into-philosophy',
      contentMDX: `
# A Deep Dive into Philosophy

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, quis aliquam nisl nunc quis nisl.

## Existentialism

Existentialism is a philosophical theory that emphasizes the existence of the individual person as a free and responsible agent determining their own development through acts of the will.

## Stoicism

Stoicism is a philosophy of personal ethics informed by its system of logic and its views on the natural world.
      `,
      summary: 'Exploring various philosophical concepts',
      status: 'PUBLISHED',
      publishedAt: new Date(Date.now() - 86400000), // Yesterday
      seriesId: demoSeries.id
    }
  });

  console.log(`Created demo posts: ${demoPost1.title}, ${demoPost2.title}`);

  // Update series order
  await prisma.series.update({
    where: { id: demoSeries.id },
    data: {
      order: JSON.stringify([demoPost1.id, demoPost2.id])
    }
  });

  // Connect posts to tags
  await prisma.postTag.create({
    data: {
      postId: demoPost1.id,
      tagId: tagTech.id
    }
  });

  await prisma.postTag.create({
    data: {
      postId: demoPost2.id,
      tagId: tagPhilosophy.id
    }
  });

  // Create some comments
  await prisma.comment.create({
    data: {
      postId: demoPost1.id,
      authorName: 'John Doe',
      authorEmail: 'john@example.com',
      body: 'Great first post! Looking forward to more content.'
    }
  });

  const parentComment = await prisma.comment.create({
    data: {
      postId: demoPost2.id,
      authorName: 'Jane Smith',
      authorEmail: 'jane@example.com',
      body: 'I really enjoyed your exploration of existentialism.'
    }
  });

  await prisma.comment.create({
    data: {
      postId: demoPost2.id,
      parentId: parentComment.id,
      authorName: 'Alex Johnson',
      authorEmail: 'alex@example.com',
      body: 'I agree! The quote from Sartre was particularly insightful.'
    }
  });

  console.log('Created demo comments');

  // Create outbound links
  await prisma.outboundLink.create({
    data: {
      postId: demoPost1.id,
      url: 'https://example.com/blog',
      lastCheckedAt: new Date()
    }
  });

  await prisma.outboundLink.create({
    data: {
      postId: demoPost2.id,
      url: 'https://plato.stanford.edu/entries/existentialism/',
      lastCheckedAt: new Date()
    }
  });

  console.log('Created demo outbound links');

  // Create reactions
  await prisma.reaction.create({
    data: {
      postId: demoPost1.id,
      type: 'LIKE',
      userIpHash: 'hash123'
    }
  });

  await prisma.reaction.create({
    data: {
      postId: demoPost2.id,
      type: 'CLAP',
      userIpHash: 'hash456'
    }
  });

  console.log('Created demo reactions');

  console.log('Seeding completed.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
import { describe, it, expect } from 'vitest';
import { app, prisma, generateTestToken } from './setup';
import { AppRouter } from '../src/routers';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import superjson from 'superjson';

// Create a trpc client for testing
const client = createTRPCProxyClient<AppRouter>({
  links: [
    httpBatchLink({
      url: 'http://localhost:3000/api/trpc',
      fetch: async (url, options) => {
        const response = await app.inject({
          method: options?.method || 'GET',
          url: url.toString(),
          headers: options?.headers as Record<string, string>,
          payload: options?.body,
        });

        return {
          ok: response.statusCode >= 200 && response.statusCode < 300,
          status: response.statusCode,
          headers: new Headers(response.headers as Record<string, string>),
          json: async () => JSON.parse(response.payload),
          text: async () => response.payload,
        } as Response;
      },
    }),
  ],
  transformer: superjson,
});

describe('Auth Router', () => {
  it('should allow login with valid credentials', async () => {
    const result = await client.auth.login.mutate({
      email: 'test@example.com',
      password: 'password',
    });

    expect(result).toHaveProperty('accessToken');
    expect(result).toHaveProperty('refreshToken');
    expect(result.user).toHaveProperty('email', 'test@example.com');
    expect(result.user).toHaveProperty('role', 'ADMIN');
  });

  it('should fail login with invalid credentials', async () => {
    try {
      await client.auth.login.mutate({
        email: 'test@example.com',
        password: 'wrongpassword',
      });
      // If we reach here, the test should fail
      expect(true).toBe(false);
    } catch (error: any) {
      expect(error.message).toContain('Invalid password');
    }
  });

  it('should fetch current user info with valid token', async () => {
    // Create a special client with auth header
    const token = generateTestToken('test-admin-id');
    
    const authedClient = createTRPCProxyClient<AppRouter>({
      links: [
        httpBatchLink({
          url: 'http://localhost:3000/api/trpc',
          headers: {
            Authorization: `Bearer ${token}`,
          },
          fetch: async (url, options) => {
            const response = await app.inject({
              method: options?.method || 'GET',
              url: url.toString(),
              headers: options?.headers as Record<string, string>,
              payload: options?.body,
            });
    
            return {
              ok: response.statusCode >= 200 && response.statusCode < 300,
              status: response.statusCode,
              headers: new Headers(response.headers as Record<string, string>),
              json: async () => JSON.parse(response.payload),
              text: async () => response.payload,
            } as Response;
          },
        }),
      ],
      transformer: superjson,
    });

    const result = await authedClient.auth.me.query();
    expect(result).toHaveProperty('user');
    expect(result.user).toHaveProperty('id', 'test-admin-id');
    expect(result.user).toHaveProperty('email', 'test@example.com');
    expect(result.user).toHaveProperty('role', 'ADMIN');
  });
});
import { beforeAll, afterAll } from 'vitest';
import { PrismaClient } from '@prisma/client';
import { execSync } from 'child_process';
import { createServer } from '../src/server/index.js';
import jwt from 'jsonwebtoken';
import { config } from '../src/config.js';

// Create a Prisma client for tests
export const prisma = new PrismaClient({
  datasourceUrl: 'file:./test.db',
});

// Create a Fastify instance for testing
export let app: Awaited<ReturnType<typeof createServer>>;

// Generate test tokens
export function generateTestToken(userId: string, role: string = 'ADMIN') {
  return jwt.sign(
    { userId, email: 'test@example.com', role, type: 'access' },
    config.JWT_SECRET,
    { expiresIn: '1h' }
  );
}

// Reset the test database before tests
beforeAll(async () => {
  try {
    // Setup test database
    execSync('npx prisma migrate reset --force --skip-generate --skip-seed', {
      env: {
        ...process.env,
        DATABASE_URL: 'file:./test.db',
      },
    });

    // Create testing server
    app = await createServer();

    // Add test user
    await prisma.user.create({
      data: {
        id: 'test-admin-id',
        email: 'test@example.com',
        hash: await import('bcrypt').then((bcrypt) => bcrypt.hash('password', 10)),
        role: 'ADMIN',
      },
    });
  } catch (error) {
    console.error('Test setup failed:', error);
    throw error;
  }
});

// Clean up resources after tests
afterAll(async () => {
  await prisma.$disconnect();
  await app.close();
});
import 'dotenv/config';
import { startServer } from './server/index.js';
import { logger } from './lib/logger.js';
import { createTelemetryProvider } from './lib/telemetry.js';
import { startWorkers, stopWorkers } from './workers/index.js';
import { config } from './config.js';

// Initialize OpenTelemetry
const telemetryProvider = createTelemetryProvider();

// Start workers if not in test mode
const workers = config.NODE_ENV !== 'test' ? startWorkers() : null;

// Start server
const server = await startServer();

// Handle graceful shutdown
const shutdown = async (signal: string) => {
  logger.info(`Received ${signal}, shutting down...`);

  if (workers) {
    logger.info('Stopping workers...');
    await stopWorkers(workers);
  }

  logger.info('Closing server...');
  await server.close();

  if (telemetryProvider) {
    logger.info('Shutting down telemetry...');
    await telemetryProvider.shutdown();
  }

  logger.info('Shutdown complete');
  process.exit(0);
};

// Listen for termination signals
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Handle uncaught errors
process.on('uncaughtException', (error) => {
  logger.error({ error }, 'Uncaught exception');
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  logger.error({ reason }, 'Unhandled rejection');
  process.exit(1);
});
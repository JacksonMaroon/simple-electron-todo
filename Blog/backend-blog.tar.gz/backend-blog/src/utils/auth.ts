import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { config } from '../config.js';

// Interface for JWT payload
export interface JwtPayload {
  userId: string;
  email: string;
  role: string;
  type: 'access' | 'refresh';
}

// Generate JWT token
export function generateToken(
  payload: Omit<JwtPayload, 'type'>, 
  type: 'access' | 'refresh' = 'access'
): string {
  const expiresIn = type === 'access' 
    ? config.JWT_EXPIRES_IN 
    : config.JWT_REFRESH_EXPIRES_IN;
  
  return jwt.sign(
    { ...payload, type },
    config.JWT_SECRET,
    { expiresIn }
  );
}

// Verify JWT token
export function verifyToken(token: string): JwtPayload {
  try {
    const decoded = jwt.verify(token, config.JWT_SECRET) as JwtPayload;
    return decoded;
  } catch (error) {
    throw new Error('Invalid token');
  }
}

// Generate refresh token
export function generateRefreshToken(payload: Omit<JwtPayload, 'type'>): string {
  return generateToken(payload, 'refresh');
}

// Hash password
export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 10;
  return bcrypt.hash(password, saltRounds);
}

// Compare password with hash
export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// Generate tokens for user session
export function generateTokens(user: { id: string; email: string; role: string }) {
  const payload = {
    userId: user.id,
    email: user.email,
    role: user.role,
  };

  const accessToken = generateToken(payload);
  const refreshToken = generateRefreshToken(payload);

  return {
    accessToken,
    refreshToken,
  };
}
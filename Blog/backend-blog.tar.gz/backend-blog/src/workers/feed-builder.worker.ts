import { Job } from 'bullmq';
import { prisma } from '../lib/prisma.js';
import { logger } from '../lib/logger.js';
import { Feed } from 'feed';
import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { config } from '../config.js';

// Convert __dirname in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FeedBuilderJob {
  timestamp: string;
}

// Feed builder worker processor
export async function feedBuilderProcessor(job: Job<FeedBuilderJob>): Promise<any> {
  logger.info({ jobId: job.id }, 'Starting feed builder job');

  try {
    // Site details would typically come from config or database
    const siteUrl = 'https://example.com'; // Placeholder - would come from config
    const siteTitle = 'My Blog';
    const siteDescription = 'A blog about technology and philosophy';
    const author = {
      name: 'Blog Author',
      email: 'author@example.com',
      link: 'https://example.com/about',
    };

    // Get all published posts
    const posts = await prisma.post.findMany({
      where: {
        status: 'PUBLISHED',
        deleted: false,
      },
      include: {
        tags: {
          include: {
            tag: true,
          },
        },
      },
      orderBy: {
        publishedAt: 'desc',
      },
      take: 20, // Limit to most recent 20 posts
    });

    // Create feed generator
    const feed = new Feed({
      title: siteTitle,
      description: siteDescription,
      id: siteUrl,
      link: siteUrl,
      language: 'en',
      image: `${siteUrl}/favicon.png`,
      favicon: `${siteUrl}/favicon.ico`,
      copyright: `All rights reserved ${new Date().getFullYear()}, ${author.name}`,
      updated: posts.length > 0 ? new Date(posts[0].updatedAt) : new Date(),
      feedLinks: {
        rss: `${siteUrl}/public/rss.xml`,
        atom: `${siteUrl}/public/atom.xml`,
        json: `${siteUrl}/public/feed.json`,
      },
      author: {
        name: author.name,
        email: author.email,
        link: author.link,
      },
    });

    // Add each post to the feed
    posts.forEach((post) => {
      // Strip out HTML content for feed
      const content = post.contentMDX
        .replace(/<[^>]*>?/gm, '') // Remove HTML tags
        .substring(0, 5000); // Truncate long content
      
      feed.addItem({
        title: post.title,
        id: `${siteUrl}/posts/${post.slug}`,
        link: `${siteUrl}/posts/${post.slug}`,
        description: post.summary || content.substring(0, 240) + '...',
        content,
        author: [
          {
            name: author.name,
            email: author.email,
            link: author.link,
          },
        ],
        date: post.publishedAt || post.updatedAt,
        image: post.summary 
          ? `${siteUrl}/api/og?title=${encodeURIComponent(post.title)}`
          : undefined,
        category: post.tags.map((t) => ({
          name: t.tag.name,
        })),
      });
    });

    // Ensure public directory exists
    const publicDir = path.join(__dirname, '..', '..', '..', 'public');
    try {
      await fs.mkdir(publicDir, { recursive: true });
    } catch (error) {
      logger.error({ error }, 'Failed to create public directory');
      throw error;
    }

    // Write the feeds to disk
    await Promise.all([
      fs.writeFile(path.join(publicDir, 'rss.xml'), feed.rss2()),
      fs.writeFile(path.join(publicDir, 'atom.xml'), feed.atom1()),
      fs.writeFile(path.join(publicDir, 'feed.json'), feed.json1()),
    ]);

    // Generate sitemap.xml
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${siteUrl}</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
${posts
  .map(
    (post) => `  <url>
    <loc>${siteUrl}/posts/${post.slug}</loc>
    <lastmod>${new Date(post.updatedAt).toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>`
  )
  .join('\n')}
</urlset>`;

    await fs.writeFile(path.join(publicDir, 'sitemap.xml'), sitemap);

    const results = {
      postsProcessed: posts.length,
      feedsGenerated: ['rss.xml', 'atom.xml', 'feed.json', 'sitemap.xml'],
      timestamp: new Date().toISOString(),
    };

    logger.info({ results }, 'Feed builder job completed');
    return results;
  } catch (error) {
    logger.error({ error }, 'Feed builder job failed');
    throw error;
  }
}
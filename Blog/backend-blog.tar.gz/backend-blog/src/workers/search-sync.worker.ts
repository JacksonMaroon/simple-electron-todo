import { Job } from 'bullmq';
import { prisma } from '../lib/prisma.js';
import { logger } from '../lib/logger.js';
import { config } from '../config.js';
import algoliasearch from 'algoliasearch';

interface SearchSyncJob {
  timestamp: string;
  postId?: string; // Optional specific post to sync
}

// Search sync worker processor
export async function searchSyncProcessor(job: Job<SearchSyncJob>): Promise<any> {
  logger.info({ jobId: job.id, data: job.data }, 'Starting search sync job');
  
  // Check if Algolia is configured
  if (!config.ALGOLIA_APP_ID || !config.ALGOLIA_API_KEY) {
    logger.warn('Algolia is not configured, skipping search sync');
    return { 
      success: false, 
      message: 'Algolia is not configured' 
    };
  }

  try {
    // Initialize Algolia client
    const client = algoliasearch(
      config.ALGOLIA_APP_ID,
      config.ALGOLIA_API_KEY
    );
    const index = client.initIndex(config.ALGOLIA_INDEX_NAME);

    // Determine if we're syncing a specific post or all posts
    if (job.data.postId) {
      // Sync a specific post
      const post = await prisma.post.findUnique({
        where: { 
          id: job.data.postId,
          deleted: false,
        },
        include: {
          tags: {
            include: {
              tag: true,
            },
          },
        },
      });

      if (!post) {
        throw new Error(`Post with ID ${job.data.postId} not found or deleted`);
      }

      // Format post for Algolia
      const algoliaPost = {
        objectID: post.id,
        title: post.title,
        slug: post.slug,
        content: post.contentMDX,
        summary: post.summary,
        status: post.status,
        publishedAt: post.publishedAt?.toISOString(),
        updatedAt: post.updatedAt.toISOString(),
        tags: post.tags.map(t => t.tag.name),
      };

      // Save to Algolia
      await index.saveObject(algoliaPost);
      
      logger.info({ postId: post.id }, 'Post synced to Algolia');
      return { 
        success: true, 
        synced: [post.id],
        deleted: [],
      };
    } else {
      // Full sync of all posts
      // Get all published posts
      const posts = await prisma.post.findMany({
        where: {
          status: 'PUBLISHED',
          deleted: false,
        },
        include: {
          tags: {
            include: {
              tag: true,
            },
          },
        },
      });

      // Format posts for Algolia
      const algoliaPosts = posts.map(post => ({
        objectID: post.id,
        title: post.title,
        slug: post.slug,
        content: post.contentMDX,
        summary: post.summary,
        status: post.status,
        publishedAt: post.publishedAt?.toISOString(),
        updatedAt: post.updatedAt.toISOString(),
        tags: post.tags.map(t => t.tag.name),
      }));

      // Save all posts to Algolia
      await index.saveObjects(algoliaPosts);

      // Delete any posts that are not published or are marked as deleted
      const deletedPosts = await prisma.post.findMany({
        where: {
          OR: [
            { status: { not: 'PUBLISHED' } },
            { deleted: true },
          ],
        },
        select: {
          id: true,
        },
      });

      if (deletedPosts.length > 0) {
        const objectIDs = deletedPosts.map(post => post.id);
        await index.deleteObjects(objectIDs);
      }

      logger.info({
        postsSynced: algoliaPosts.length,
        postsDeleted: deletedPosts.length,
      }, 'All posts synced to Algolia');

      return { 
        success: true, 
        synced: algoliaPosts.map(p => p.objectID),
        deleted: deletedPosts.map(p => p.id),
      };
    }
  } catch (error) {
    logger.error({ error }, 'Search sync job failed');
    throw error;
  }
}
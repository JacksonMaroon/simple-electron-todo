import { Job } from 'bullmq';
import { prisma } from '../lib/prisma.js';
import { logger } from '../lib/logger.js';
import { config } from '../config.js';
import path from 'path';
import fs from 'fs/promises';
import puppeteer from 'puppeteer';
import { v4 as uuidv4 } from 'uuid';

interface SnapshotJob {
  linkId: string;
  postId: string;
  url: string;
  type: 'HTML' | 'PDF' | 'PNG';
}

// Snapshot taker worker processor
export async function snapshotTakerProcessor(job: Job<SnapshotJob>): Promise<any> {
  logger.info({ jobId: job.id, data: job.data }, 'Starting snapshot job');
  const { linkId, postId, url, type } = job.data;

  let browser;
  try {
    // Check if link exists
    const link = await prisma.outboundLink.findUnique({
      where: { id: linkId },
    });

    if (!link) {
      throw new Error(`Link with ID ${linkId} not found`);
    }

    // Create a temporary directory for storing snapshots
    const tempDir = path.join(process.cwd(), 'tmp');
    await fs.mkdir(tempDir, { recursive: true });

    // Generate a unique filename
    const filename = `${Date.now()}-${uuidv4()}`;
    let outputPath;
    let storeUrl;

    // Launch a headless browser
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });
    
    const page = await browser.newPage();
    
    // Set viewport size
    await page.setViewport({ width: 1280, height: 800 });
    
    // Navigate to the URL
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });

    // Take snapshot based on type
    switch (type) {
      case 'HTML':
        // Get the full HTML content
        const html = await page.content();
        outputPath = path.join(tempDir, `${filename}.html`);
        await fs.writeFile(outputPath, html);
        
        // If configured, upload to external storage (S3, Backblaze, etc.)
        // For now, just store locally
        storeUrl = `/snapshots/${filename}.html`;
        break;
        
      case 'PDF':
        outputPath = path.join(tempDir, `${filename}.pdf`);
        await page.pdf({
          path: outputPath,
          format: 'A4',
          printBackground: true,
        });
        storeUrl = `/snapshots/${filename}.pdf`;
        break;
        
      case 'PNG':
        outputPath = path.join(tempDir, `${filename}.png`);
        await page.screenshot({
          path: outputPath,
          fullPage: true,
        });
        storeUrl = `/snapshots/${filename}.png`;
        break;
        
      default:
        throw new Error(`Unsupported snapshot type: ${type}`);
    }

    // Create a snapshot record in the database
    const snapshot = await prisma.snapshot.create({
      data: {
        postId,
        type,
        storeUrl,
      },
    });

    // In a production environment, you would upload the file to S3/Backblaze here
    // and update the storeUrl with the actual URL
    
    // Ensure the public/snapshots directory exists
    const snapshotsDir = path.join(process.cwd(), 'public', 'snapshots');
    await fs.mkdir(snapshotsDir, { recursive: true });
    
    // Copy the file to the public directory
    const publicPath = path.join(snapshotsDir, path.basename(outputPath));
    await fs.copyFile(outputPath, publicPath);
    
    // Clean up the temporary file
    await fs.unlink(outputPath);

    logger.info({ snapshot }, 'Snapshot created successfully');
    return { success: true, snapshotId: snapshot.id, storeUrl };
  } catch (error) {
    logger.error({ error, url }, 'Snapshot job failed');
    throw error;
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}
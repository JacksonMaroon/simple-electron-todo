import { Job } from 'bullmq';
import { prisma } from '../lib/prisma.js';
import { logger } from '../lib/logger.js';
import fetch from 'node-fetch';

interface LinkCheckerJob {
  timestamp: string;
}

// Link checker worker processor
export async function linkCheckerProcessor(job: Job<LinkCheckerJob>): Promise<any> {
  logger.info({ jobId: job.id }, 'Starting link checker job');

  try {
    // Get all links that haven't been checked in the last week
    // or have never been checked
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const links = await prisma.outboundLink.findMany({
      where: {
        OR: [
          { lastCheckedAt: null },
          { lastCheckedAt: { lt: oneWeekAgo } },
        ],
      },
      include: {
        post: {
          select: {
            id: true,
            title: true,
          },
        },
      },
    });

    logger.info({ count: links.length }, 'Found links to check');

    // Process links in batches to avoid overwhelming the network
    const batchSize = 10;
    const results = {
      total: links.length,
      alive: 0,
      dead: 0,
      errors: 0,
    };

    for (let i = 0; i < links.length; i += batchSize) {
      const batch = links.slice(i, i + batchSize);
      
      // Process batch in parallel
      await Promise.all(
        batch.map(async (link) => {
          try {
            // Check if the link is alive
            const response = await fetch(link.url, {
              method: 'HEAD',
              timeout: 5000, // 5 second timeout
              redirect: 'follow',
            });

            const isDead = response.status >= 400;
            
            // Update the link
            await prisma.outboundLink.update({
              where: { id: link.id },
              data: {
                isDead,
                lastCheckedAt: new Date(),
              },
            });

            isDead ? results.dead++ : results.alive++;
          } catch (error) {
            logger.error({ error, link: link.url }, 'Error checking link');
            
            // Mark as dead if we couldn't connect
            await prisma.outboundLink.update({
              where: { id: link.id },
              data: {
                isDead: true,
                lastCheckedAt: new Date(),
              },
            });
            
            results.dead++;
            results.errors++;
          }
        })
      );

      // Small delay between batches
      if (i + batchSize < links.length) {
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
    }

    logger.info({ results }, 'Link checker job completed');
    return results;
  } catch (error) {
    logger.error({ error }, 'Link checker job failed');
    throw error;
  }
}
import { z } from 'zod';
import { publicProcedure, router } from './trpc.js';
import { redisClient } from '../lib/redis.js';
import { config } from '../config.js';
import algoliasearch from 'algoliasearch';

// Health check router
export const healthRouter = router({
  // Basic health check for the API
  check: publicProcedure
    .output(
      z.object({
        status: z.enum(['ok', 'error']),
        timestamp: z.string().datetime(),
        services: z.object({
          database: z.enum(['ok', 'error', 'unknown', 'disabled']),
          redis: z.enum(['ok', 'error', 'unknown', 'disabled']),
          algolia: z.enum(['ok', 'error', 'unknown', 'disabled']),
        }),
      })
    )
    .query(async ({ ctx }) => {
      const { prisma } = ctx;
      
      const health = {
        status: 'ok' as const,
        timestamp: new Date().toISOString(),
        services: {
          database: 'unknown' as const,
          redis: (config.REDIS_URL ? 'unknown' : 'disabled') as const,
          algolia: (config.ALGOLIA_APP_ID ? 'unknown' : 'disabled') as const,
        },
      };

      // Check database
      try {
        await prisma.$queryRaw`SELECT 1`;
        health.services.database = 'ok';
      } catch (error) {
        health.services.database = 'error';
        health.status = 'error';
      }

      // Check Redis if configured
      if (config.REDIS_URL && redisClient) {
        try {
          const ping = await redisClient.ping();
          health.services.redis = ping === 'PONG' ? 'ok' : 'error';
          if (health.services.redis === 'error') {
            health.status = 'error';
          }
        } catch (error) {
          health.services.redis = 'error';
          health.status = 'error';
        }
      }

      // Check Algolia if configured
      if (config.ALGOLIA_APP_ID && config.ALGOLIA_API_KEY) {
        try {
          const client = algoliasearch(
            config.ALGOLIA_APP_ID,
            config.ALGOLIA_API_KEY
          );
          const index = client.initIndex(config.ALGOLIA_INDEX_NAME);
          const result = await index.getSettings();
          health.services.algolia = result ? 'ok' : 'error';
          if (health.services.algolia === 'error') {
            health.status = 'error';
          }
        } catch (error) {
          health.services.algolia = 'error';
          health.status = 'error';
        }
      }

      return health;
    }),
});
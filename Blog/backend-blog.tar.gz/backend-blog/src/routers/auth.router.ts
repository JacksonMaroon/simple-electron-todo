import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { authenticatedProcedure, publicProcedure, router } from './trpc.js';
import { comparePassword, generateTokens, hashPassword, verifyToken } from '../utils/auth.js';

// Define validation schemas
const userSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

const tokenSchema = z.object({
  refreshToken: z.string(),
});

const resetPasswordSchema = z.object({
  email: z.string().email(),
});

// Auth router with login, signup, refresh, and forgot-password endpoints
export const authRouter = router({
  // Login endpoint
  login: publicProcedure
    .input(userSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { email, password } = input;

      // Find user by email
      const user = await prisma.user.findUnique({
        where: { email },
      });

      if (!user) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found',
        });
      }

      // Verify password
      const isPasswordValid = await comparePassword(password, user.hash);
      if (!isPasswordValid) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Invalid password',
        });
      }

      // Generate tokens
      const tokens = generateTokens({
        id: user.id,
        email: user.email,
        role: user.role,
      });

      return {
        user: {
          id: user.id,
          email: user.email,
          role: user.role,
        },
        ...tokens,
      };
    }),

  // Signup endpoint
  signup: publicProcedure
    .input(userSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { email, password } = input;

      // Check if user already exists
      const existingUser = await prisma.user.findUnique({
        where: { email },
      });

      if (existingUser) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'User already exists',
        });
      }

      // Hash password
      const hash = await hashPassword(password);

      // Create user
      const user = await prisma.user.create({
        data: {
          email,
          hash,
          role: 'READER', // Default role
        },
      });

      // Generate tokens
      const tokens = generateTokens({
        id: user.id,
        email: user.email,
        role: user.role,
      });

      return {
        user: {
          id: user.id,
          email: user.email,
          role: user.role,
        },
        ...tokens,
      };
    }),

  // Refresh token endpoint
  refresh: publicProcedure
    .input(tokenSchema)
    .mutation(async ({ input }) => {
      const { refreshToken } = input;

      try {
        // Verify refresh token
        const decoded = verifyToken(refreshToken);

        // Check if it's a refresh token
        if (decoded.type !== 'refresh') {
          throw new TRPCError({
            code: 'UNAUTHORIZED',
            message: 'Invalid token type',
          });
        }

        // Generate new tokens
        const tokens = generateTokens({
          id: decoded.userId,
          email: decoded.email,
          role: decoded.role,
        });

        return tokens;
      } catch (error) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Invalid or expired refresh token',
        });
      }
    }),

  // Forgot password endpoint
  forgotPassword: publicProcedure
    .input(resetPasswordSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { email } = input;

      // Check if user exists
      const user = await prisma.user.findUnique({
        where: { email },
      });

      if (!user) {
        // For security reasons, always return success even if user doesn't exist
        return { success: true };
      }

      // Here you would typically:
      // 1. Generate a reset token
      // 2. Store it in a database or cache with an expiration
      // 3. Send an email with a reset link

      // For now, we just return success
      return { success: true };
    }),

  // Get current user info
  me: authenticatedProcedure
    .query(async ({ ctx }) => {
      return {
        user: ctx.user,
      };
    }),
});
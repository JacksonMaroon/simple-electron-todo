import { router } from './trpc.js';
import { healthRouter } from './health.router.js';
import { authRouter } from './auth.router.js';
import { postsRouter } from './posts.router.js';
import { commentsRouter } from './comments.router.js';
import { tagsRouter } from './tags.router.js';
import { seriesRouter } from './series.router.js';
import { searchRouter } from './search.router.js';
import { feedsRouter } from './feeds.router.js';
import { linksRouter } from './links.router.js';
import { reactionsRouter } from './reactions.router.js';

// Main application router that combines all route handlers
export const appRouter = router({
  health: healthRouter,
  auth: authRouter,
  posts: postsRouter,
  comments: commentsRouter,
  tags: tagsRouter,
  series: seriesRouter,
  search: searchRouter,
  feeds: feedsRouter,
  links: linksRouter,
  reactions: reactionsRouter,
});

// Export type definition of API
export type AppRouter = typeof appRouter;
import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { publicProcedure, router } from './trpc.js';
import algoliasearch from 'algoliasearch';
import { config } from '../config.js';

// Define validation schemas
const searchQuerySchema = z.object({
  query: z.string().min(1).max(100),
  page: z.number().int().min(1).default(1),
  hitsPerPage: z.number().int().min(1).max(100).default(10),
  filters: z.string().optional(), // Algolia filter syntax
});

// Search router for Algolia integration
export const searchRouter = router({
  // Search for posts
  query: publicProcedure
    .input(searchQuerySchema)
    .query(async ({ input }) => {
      const { query, page, hitsPerPage, filters } = input;

      // Check if Algolia is configured
      if (!config.ALGOLIA_APP_ID || !config.ALGOLIA_API_KEY) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Search service is not configured',
        });
      }

      try {
        // Initialize Algolia client
        const client = algoliasearch(
          config.ALGOLIA_APP_ID,
          config.ALGOLIA_API_KEY
        );
        const index = client.initIndex(config.ALGOLIA_INDEX_NAME);

        // Perform search
        const result = await index.search(query, {
          page: page - 1, // Algolia uses 0-based indexing
          hitsPerPage,
          filters,
        });

        // Format the response
        return {
          hits: result.hits,
          pagination: {
            page,
            hitsPerPage,
            totalHits: result.nbHits,
            totalPages: result.nbPages,
          },
        };
      } catch (error) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Search failed',
          cause: error,
        });
      }
    }),

  // Generate a search API key for client-side use (with restricted access)
  getApiKey: publicProcedure
    .query(async () => {
      // Check if Algolia is configured
      if (!config.ALGOLIA_APP_ID || !config.ALGOLIA_API_KEY) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Search service is not configured',
        });
      }

      try {
        // Initialize Algolia client
        const client = algoliasearch(
          config.ALGOLIA_APP_ID,
          config.ALGOLIA_API_KEY
        );

        // Generate secured API key that can only be used for searching
        // and can only access specific indices
        const apiKey = client.generateSecuredApiKey(
          config.ALGOLIA_API_KEY,
          {
            filters: 'status:PUBLISHED', // Only search published posts
            validUntil: Math.floor(Date.now() / 1000) + 3600, // Valid for 1 hour
          }
        );

        return {
          searchApiKey: apiKey,
          appId: config.ALGOLIA_APP_ID,
          indexName: config.ALGOLIA_INDEX_NAME,
        };
      } catch (error) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to generate search API key',
          cause: error,
        });
      }
    }),
});
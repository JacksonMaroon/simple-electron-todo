import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { adminProcedure, publicProcedure, router } from './trpc.js';

// Define validation schemas
const tagSchema = z.object({
  name: z.string().min(1).max(50),
  color: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
});

const tagUpdateSchema = tagSchema.partial().extend({
  id: z.string(),
});

// Tags router for CRUD operations
export const tagsRouter = router({
  // Get all tags
  list: publicProcedure
    .query(async ({ ctx }) => {
      const { prisma } = ctx;

      const tags = await prisma.tag.findMany({
        orderBy: {
          name: 'asc',
        },
      });

      return { tags };
    }),

  // Get a single tag with post count
  getById: publicProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id } = input;

      const tag = await prisma.tag.findUnique({
        where: { id },
      });

      if (!tag) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Tag not found',
        });
      }

      // Count published posts with this tag
      const postCount = await prisma.postTag.count({
        where: {
          tagId: id,
          post: {
            status: 'PUBLISHED',
            deleted: false,
          },
        },
      });

      return {
        ...tag,
        postCount,
      };
    }),

  // Create a new tag (admin only)
  create: adminProcedure
    .input(tagSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { name, color } = input;

      // Check if tag with name already exists
      const existingTag = await prisma.tag.findFirst({
        where: {
          name: {
            equals: name,
            mode: 'insensitive', // Case insensitive comparison
          },
        },
      });

      if (existingTag) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'Tag with this name already exists',
        });
      }

      // Create tag
      const tag = await prisma.tag.create({
        data: {
          name,
          color,
        },
      });

      return tag;
    }),

  // Update an existing tag (admin only)
  update: adminProcedure
    .input(tagUpdateSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id, name, color } = input;

      // Check if tag exists
      const existingTag = await prisma.tag.findUnique({
        where: { id },
      });

      if (!existingTag) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Tag not found',
        });
      }

      // If changing name, check if already exists
      if (name && name !== existingTag.name) {
        const nameExists = await prisma.tag.findFirst({
          where: {
            name: {
              equals: name,
              mode: 'insensitive', // Case insensitive comparison
            },
            id: {
              not: id,
            },
          },
        });

        if (nameExists) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'Tag with this name already exists',
          });
        }
      }

      // Update tag
      const tag = await prisma.tag.update({
        where: { id },
        data: {
          name,
          color,
        },
      });

      return tag;
    }),

  // Delete a tag (admin only)
  delete: adminProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id } = input;

      // Check if tag exists
      const existingTag = await prisma.tag.findUnique({
        where: { id },
      });

      if (!existingTag) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Tag not found',
        });
      }

      // Delete tag and all its relations
      await prisma.tag.delete({
        where: { id },
      });

      return { success: true };
    }),
});
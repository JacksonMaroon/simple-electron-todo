import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { adminProcedure, router } from './trpc.js';
import { prisma } from '../lib/prisma.js';
import { Feed } from 'feed';
import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Convert __dirname in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define validation schemas
const regenerateFeedsSchema = z.object({
  siteUrl: z.string().url(),
  title: z.string().default('My Blog'),
  description: z.string().default('Blog feed'),
  author: z.object({
    name: z.string(),
    email: z.string().email().optional(),
    link: z.string().url().optional(),
  }),
});

// Feeds router for RSS, Atom, and JSON feeds
export const feedsRouter = router({
  // Regenerate all feeds
  regenerate: adminProcedure
    .input(regenerateFeedsSchema)
    .mutation(async ({ input }) => {
      const { siteUrl, title, description, author } = input;
      
      // Get all published posts
      const posts = await prisma.post.findMany({
        where: {
          status: 'PUBLISHED',
          deleted: false,
        },
        include: {
          tags: {
            include: {
              tag: true,
            },
          },
        },
        orderBy: {
          publishedAt: 'desc',
        },
        take: 20, // Limit to most recent 20 posts
      });

      // Create feed generator
      const feed = new Feed({
        title,
        description,
        id: siteUrl,
        link: siteUrl,
        language: 'en',
        image: `${siteUrl}/favicon.png`,
        favicon: `${siteUrl}/favicon.ico`,
        copyright: `All rights reserved ${new Date().getFullYear()}, ${author.name}`,
        updated: posts.length > 0 ? new Date(posts[0].updatedAt) : new Date(),
        feedLinks: {
          rss: `${siteUrl}/public/rss.xml`,
          atom: `${siteUrl}/public/atom.xml`,
          json: `${siteUrl}/public/feed.json`,
        },
        author: {
          name: author.name,
          email: author.email,
          link: author.link,
        },
      });

      // Add each post to the feed
      posts.forEach((post) => {
        // Strip out HTML content for feed
        const content = post.contentMDX
          .replace(/<[^>]*>?/gm, '') // Remove HTML tags
          .substring(0, 5000); // Truncate long content
        
        feed.addItem({
          title: post.title,
          id: `${siteUrl}/posts/${post.slug}`,
          link: `${siteUrl}/posts/${post.slug}`,
          description: post.summary || content.substring(0, 240) + '...',
          content,
          author: [
            {
              name: author.name,
              email: author.email,
              link: author.link,
            },
          ],
          date: post.publishedAt || post.updatedAt,
          image: post.summary 
            ? `${siteUrl}/api/og?title=${encodeURIComponent(post.title)}`
            : undefined,
          category: post.tags.map((t) => ({
            name: t.tag.name,
          })),
        });
      });

      // Ensure public directory exists
      const publicDir = path.join(__dirname, '..', '..', 'public');
      try {
        await fs.mkdir(publicDir, { recursive: true });
      } catch (error) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create public directory',
          cause: error,
        });
      }

      // Write the feeds to disk
      try {
        await Promise.all([
          fs.writeFile(path.join(publicDir, 'rss.xml'), feed.rss2()),
          fs.writeFile(path.join(publicDir, 'atom.xml'), feed.atom1()),
          fs.writeFile(path.join(publicDir, 'feed.json'), feed.json1()),
        ]);
      } catch (error) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to write feed files',
          cause: error,
        });
      }

      // Generate sitemap.xml
      try {
        const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${siteUrl}</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
${posts
  .map(
    (post) => `  <url>
    <loc>${siteUrl}/posts/${post.slug}</loc>
    <lastmod>${new Date(post.updatedAt).toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>`
  )
  .join('\n')}
</urlset>`;

        await fs.writeFile(path.join(publicDir, 'sitemap.xml'), sitemap);
      } catch (error) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to write sitemap file',
          cause: error,
        });
      }

      return {
        success: true,
        feedUrls: {
          rss: `${siteUrl}/public/rss.xml`,
          atom: `${siteUrl}/public/atom.xml`,
          json: `${siteUrl}/public/feed.json`,
          sitemap: `${siteUrl}/public/sitemap.xml`,
        },
      };
    }),
});
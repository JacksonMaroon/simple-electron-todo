import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { adminProcedure, publicProcedure, router } from './trpc.js';
import { redisClient } from '../lib/redis.js';
import { Queue } from 'bullmq';

// Define validation schemas
const linkActionSchema = z.object({
  id: z.string(),
});

const snapshotLinkSchema = z.object({
  id: z.string(),
  type: z.enum(['HTML', 'PDF', 'PNG']).default('PDF'),
});

// Get BullMQ queue for links if Redis is available
const getLinksQueue = () => {
  if (!redisClient) {
    throw new TRPCError({
      code: 'INTERNAL_SERVER_ERROR',
      message: 'Redis connection is required for this operation',
    });
  }

  return new Queue('links', { connection: redisClient });
};

// Links router for managing outbound links
export const linksRouter = router({
  // Mark a link as dead
  markDead: adminProcedure
    .input(linkActionSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id } = input;

      // Check if link exists
      const link = await prisma.outboundLink.findUnique({
        where: { id },
      });

      if (!link) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Link not found',
        });
      }

      // Update the link
      const updatedLink = await prisma.outboundLink.update({
        where: { id },
        data: {
          isDead: true,
          lastCheckedAt: new Date(),
        },
      });

      return updatedLink;
    }),

  // Mark a link as alive (not dead)
  markAlive: adminProcedure
    .input(linkActionSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id } = input;

      // Check if link exists
      const link = await prisma.outboundLink.findUnique({
        where: { id },
      });

      if (!link) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Link not found',
        });
      }

      // Update the link
      const updatedLink = await prisma.outboundLink.update({
        where: { id },
        data: {
          isDead: false,
          lastCheckedAt: new Date(),
        },
      });

      return updatedLink;
    }),

  // Take a snapshot of a link
  snapshotLink: adminProcedure
    .input(snapshotLinkSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id, type } = input;

      // Check if link exists
      const link = await prisma.outboundLink.findUnique({
        where: { id },
        include: {
          post: {
            select: {
              id: true,
              title: true,
            },
          },
        },
      });

      if (!link) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Link not found',
        });
      }

      try {
        // Add job to queue
        const queue = getLinksQueue();
        
        const job = await queue.add('snapshot', {
          linkId: id,
          postId: link.postId,
          url: link.url,
          type,
        });

        return {
          success: true,
          jobId: job.id,
          message: `Snapshot job added to queue (${job.id})`,
        };
      } catch (error) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to add snapshot job to queue',
          cause: error,
        });
      }
    }),

  // List all outbound links for a post
  listByPost: publicProcedure
    .input(z.object({ postId: z.string() }))
    .query(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { postId } = input;

      // Get all links for the post
      const links = await prisma.outboundLink.findMany({
        where: { postId },
        orderBy: {
          url: 'asc',
        },
      });

      return { links };
    }),

  // Get all snapshots for a link
  getSnapshots: publicProcedure
    .input(z.object({ linkId: z.string() }))
    .query(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { linkId } = input;

      // Check if link exists
      const link = await prisma.outboundLink.findUnique({
        where: { id: linkId },
      });

      if (!link) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Link not found',
        });
      }

      // Get all snapshots for the link's post
      const snapshots = await prisma.snapshot.findMany({
        where: { postId: link.postId },
        orderBy: {
          takenAt: 'desc',
        },
      });

      return { snapshots };
    }),
});
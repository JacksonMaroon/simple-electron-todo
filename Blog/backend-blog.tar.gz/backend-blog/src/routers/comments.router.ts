import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { adminProcedure, publicProcedure, router } from './trpc.js';

// Define validation schemas
const commentCreateSchema = z.object({
  postId: z.string(),
  parentId: z.string().optional(),
  authorName: z.string().min(1).max(100),
  authorEmail: z.string().email().optional(),
  authorUrl: z.string().url().optional(),
  body: z.string().min(1).max(10000),
});

const commentListSchema = z.object({
  postId: z.string(),
});

const commentActionSchema = z.object({
  id: z.string(),
});

// Comments router for managing blog comments
export const commentsRouter = router({
  // Add a new comment
  add: publicProcedure
    .input(commentCreateSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { postId, parentId, authorName, authorEmail, authorUrl, body } = input;

      // Check if post exists
      const post = await prisma.post.findUnique({
        where: { id: postId },
      });

      if (!post) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Post not found',
        });
      }

      // Check if parent comment exists if provided
      if (parentId) {
        const parentComment = await prisma.comment.findUnique({
          where: { id: parentId },
        });

        if (!parentComment) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Parent comment not found',
          });
        }

        // Ensure parent comment belongs to the same post
        if (parentComment.postId !== postId) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Parent comment does not belong to the specified post',
          });
        }
      }

      // Create the comment
      const comment = await prisma.comment.create({
        data: {
          postId,
          parentId,
          authorName,
          authorEmail,
          authorUrl,
          body,
          // Simple spam detection - would typically use a service like Akismet in production
          isSpam: body.includes('http') && (body.includes('viagra') || body.includes('cialis')),
        },
      });

      return comment;
    }),

  // List comments for a post
  list: publicProcedure
    .input(commentListSchema)
    .query(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { postId } = input;

      // Check if post exists
      const post = await prisma.post.findUnique({
        where: { id: postId },
      });

      if (!post) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Post not found',
        });
      }

      // Get all comments for the post
      const comments = await prisma.comment.findMany({
        where: {
          postId,
          deleted: false,
          isSpam: false, // Don't show spam comments to regular users
        },
        orderBy: {
          createdAt: 'asc',
        },
      });

      // Function to build comment tree
      function buildCommentTree(comments: any[], parentId: string | null = null) {
        return comments
          .filter((comment) => comment.parentId === parentId)
          .map((comment) => ({
            ...comment,
            children: buildCommentTree(comments, comment.id),
          }));
      }

      // Return a tree structure
      return {
        comments: buildCommentTree(comments),
      };
    }),

  // Mark a comment as spam (admin only)
  markSpam: adminProcedure
    .input(commentActionSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id } = input;

      // Update the comment
      const comment = await prisma.comment.update({
        where: { id },
        data: {
          isSpam: true,
        },
      });

      return comment;
    }),

  // Mark a comment as not spam (admin only)
  markNotSpam: adminProcedure
    .input(commentActionSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id } = input;

      // Update the comment
      const comment = await prisma.comment.update({
        where: { id },
        data: {
          isSpam: false,
        },
      });

      return comment;
    }),

  // Delete a comment (admin only)
  delete: adminProcedure
    .input(commentActionSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id } = input;

      // Soft delete the comment
      const comment = await prisma.comment.update({
        where: { id },
        data: {
          deleted: true,
        },
      });

      return comment;
    }),

  // List all comments including spam (admin only)
  listAll: adminProcedure
    .input(
      z.object({
        postId: z.string().optional(),
        isSpam: z.boolean().optional(),
        page: z.number().int().min(1).default(1),
        limit: z.number().int().min(1).max(100).default(50),
      })
    )
    .query(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { postId, isSpam, page, limit } = input;
      const skip = (page - 1) * limit;

      // Build filters
      const where: any = {};

      if (postId) {
        where.postId = postId;
      }

      if (isSpam !== undefined) {
        where.isSpam = isSpam;
      }

      // Get comments with count
      const [comments, total] = await Promise.all([
        prisma.comment.findMany({
          where,
          include: {
            post: {
              select: {
                title: true,
                slug: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
          skip,
          take: limit,
        }),
        prisma.comment.count({ where }),
      ]);

      return {
        comments,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit),
        },
      };
    }),
});
import { PrismaClient } from '@prisma/client';
import { isTest } from '../config.js';

// Avoid multiple instances of Prisma Client in development
declare global {
  // eslint-disable-next-line no-var
  var prisma: PrismaClient | undefined;
}

export const prisma = global.prisma || 
  new PrismaClient({
    log: isTest ? [] : ['error', 'warn'],
  });

if (process.env.NODE_ENV === 'development') {
  global.prisma = prisma;
}

export default prisma;
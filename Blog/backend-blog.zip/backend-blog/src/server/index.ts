import Fastify, { FastifyInstance } from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import staticFiles from '@fastify/static';
import { config, rateLimitConfig } from '../config.js';
import { logger } from '../lib/logger.js';
import { registerTrpcPlugin } from './plugins/trpc.js';
import { registerHealthPlugin } from './plugins/health.js';
import { registerAuthPlugin } from './plugins/auth.js';
import path from 'path';
import { fileURLToPath } from 'url';

// Convert __dirname in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create Fastify server instance
export async function createServer(): Promise<FastifyInstance> {
  const server = Fastify({
    logger,
    trustProxy: true,
  });

  // Register CORS
  await server.register(cors, {
    origin: true, // Reflect the request origin. Change this in production.
    credentials: true,
  });

  // Register Helmet for security headers
  await server.register(helmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", 'data:'],
      },
    },
  });

  // Register rate limiting
  await server.register(rateLimit, {
    max: rateLimitConfig.max,
    timeWindow: rateLimitConfig.timeWindow,
    // Different rate limit for certain routes
    routeList: [
      {
        path: '/api/trpc/auth.login',
        max: 10,
        timeWindow: '5 minutes',
      },
    ],
  });

  // Register static file serving for public directory (RSS feeds, sitemap, etc.)
  await server.register(staticFiles, {
    root: path.join(__dirname, '..', '..', 'public'),
    prefix: '/public/',
  });

  // Register the tRPC plugin
  await server.register(registerTrpcPlugin);

  // Register health check endpoint
  await server.register(registerHealthPlugin);

  // Register authentication plugin
  await server.register(registerAuthPlugin);

  // Default route
  server.get('/', async () => {
    return { message: 'Blog API Server' };
  });

  // Root error handler
  server.setErrorHandler((error, request, reply) => {
    server.log.error(error);
    reply.status(500).send({
      type: 'https://example.com/errors/internal-server-error',
      title: 'Internal Server Error',
      status: 500,
      detail: 'An unexpected error occurred',
    });
  });

  return server;
}

// Start the server
export async function startServer() {
  const server = await createServer();

  try {
    await server.listen({
      port: parseInt(config.PORT, 10),
      host: config.HOST,
    });
    
    return server;
  } catch (err) {
    server.log.error(err);
    process.exit(1);
  }
}
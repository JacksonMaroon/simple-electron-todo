import { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { fastifyTRPCPlugin } from '@trpc/server/adapters/fastify';
import { appRouter } from '../../routers/index.js';
import { createContext } from '../../routers/context.js';
import fp from 'fastify-plugin';

// Register tRPC plugin for Fastify
export const registerTrpcPlugin = fp(async (server: FastifyInstance) => {
  server.register(fastifyTRPCPlugin, {
    prefix: '/api/trpc',
    trpcOptions: {
      router: appRouter,
      createContext,
      onError({ error, path }) {
        // Log all errors from procedures
        server.log.error({ 
          path, 
          error: {
            code: error.code,
            message: error.message,
            cause: error.cause,
            stack: error.stack,
          } 
        }, 'tRPC error');
      },
    },
  });

  // Create a traditional REST endpoint that works with tRPC
  server.get('/api/healthz', async (request, reply) => {
    const caller = appRouter.createCaller(await createContext({ request, reply }));
    return caller.health.check();
  });

  // Register a handler for not found routes
  server.setNotFoundHandler((request: FastifyRequest, reply: FastifyReply) => {
    reply.status(404).send({
      type: 'https://example.com/errors/not-found',
      title: 'Resource Not Found',
      status: 404,
      detail: `Route ${request.method}:${request.url} not found`,
    });
  });
});
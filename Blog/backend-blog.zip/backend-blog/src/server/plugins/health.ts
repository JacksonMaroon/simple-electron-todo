import { FastifyInstance } from 'fastify';
import fp from 'fastify-plugin';
import { prisma } from '../../lib/prisma.js';
import { redisClient } from '../../lib/redis.js';
import { config } from '../../config.js';
import algoliasearch from 'algoliasearch';

// Health check plugin
export const registerHealthPlugin = fp(async (server: FastifyInstance) => {
  server.get('/api/healthz', async (request, reply) => {
    const health = {
      status: 'ok',
      timestamp: new Date().toISOString(),
      services: {
        database: 'unknown',
        redis: config.REDIS_URL ? 'unknown' : 'disabled',
        algolia: config.ALGOLIA_APP_ID ? 'unknown' : 'disabled',
      },
    };

    // Check database
    try {
      await prisma.$queryRaw`SELECT 1`;
      health.services.database = 'ok';
    } catch (error) {
      health.services.database = 'error';
      health.status = 'error';
      server.log.error({ error }, 'Database health check failed');
    }

    // Check Redis if configured
    if (config.REDIS_URL && redisClient) {
      try {
        const ping = await redisClient.ping();
        health.services.redis = ping === 'PONG' ? 'ok' : 'error';
        if (health.services.redis === 'error') {
          health.status = 'error';
        }
      } catch (error) {
        health.services.redis = 'error';
        health.status = 'error';
        server.log.error({ error }, 'Redis health check failed');
      }
    }

    // Check Algolia if configured
    if (config.ALGOLIA_APP_ID && config.ALGOLIA_API_KEY) {
      try {
        const client = algoliasearch(
          config.ALGOLIA_APP_ID,
          config.ALGOLIA_API_KEY
        );
        const index = client.initIndex(config.ALGOLIA_INDEX_NAME);
        const result = await index.getSettings();
        health.services.algolia = result ? 'ok' : 'error';
        if (health.services.algolia === 'error') {
          health.status = 'error';
        }
      } catch (error) {
        health.services.algolia = 'error';
        health.status = 'error';
        server.log.error({ error }, 'Algolia health check failed');
      }
    }

    // Set appropriate status code
    const statusCode = health.status === 'ok' ? 200 : 503;
    return reply.status(statusCode).send(health);
  });
});
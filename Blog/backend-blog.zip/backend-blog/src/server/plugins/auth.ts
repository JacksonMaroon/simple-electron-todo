import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import fp from 'fastify-plugin';
import { JwtPayload, verifyToken } from '../../utils/auth.js';
import { prisma } from '../../lib/prisma.js';

// Extract JWT token from headers
function extractToken(request: FastifyRequest): string | null {
  const authHeader = request.headers.authorization;
  if (!authHeader) return null;
  return authHeader.replace('Bearer ', '');
}

// Authentication plugin for Fastify
export const registerAuthPlugin = fp(async (fastify: FastifyInstance) => {
  // Register a decorator for current user
  fastify.decorateRequest('user', null);
  
  // Register a hook to authenticate users on every request
  fastify.addHook('onRequest', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      // Extract token
      const token = extractToken(request);
      if (!token) return; // No token, continue as unauthenticated
      
      // Verify token
      const payload = verifyToken(token) as JwtPayload;
      
      // Check if access token (not refresh token)
      if (payload.type !== 'access') return;
      
      // Check if user exists
      const user = await prisma.user.findUnique({
        where: { id: payload.userId },
      });
      
      if (!user) return; // User not found
      
      // Set user in request
      request.user = {
        id: user.id,
        email: user.email,
        role: user.role,
      };
    } catch (error) {
      // Invalid token, continue as unauthenticated
      request.log.error({ error }, 'Authentication error');
    }
  });
  
  // Create a route to verify authentication
  fastify.get('/api/auth/me', async (request: FastifyRequest, reply: FastifyReply) => {
    if (!request.user) {
      return reply.status(401).send({
        authenticated: false,
        message: 'Not authenticated',
      });
    }
    
    return {
      authenticated: true,
      user: request.user,
    };
  });
});
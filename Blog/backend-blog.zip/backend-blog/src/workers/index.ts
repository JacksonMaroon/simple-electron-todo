import { Worker, Queue } from 'bullmq';
import { redisClient } from '../lib/redis.js';
import { logger } from '../lib/logger.js';
import { linkCheckerProcessor } from './link-checker.worker.js';
import { feedBuilderProcessor } from './feed-builder.worker.js';
import { snapshotTakerProcessor } from './snapshot-taker.worker.js';
import { searchSyncProcessor } from './search-sync.worker.js';

// Worker types for type safety
type WorkerType = Worker | null;
type WorkersType = {
  linkChecker: WorkerType;
  feedBuilder: WorkerType;
  snapshotTaker: WorkerType;
  searchSync: WorkerType;
};

// Function to start all workers
export function startWorkers(): WorkersType | null {
  // If Redis is not available, we can't run workers
  if (!redisClient) {
    logger.warn('Redis connection not available, workers will not start');
    return null;
  }

  const workers: WorkersType = {
    linkChecker: null,
    feedBuilder: null,
    snapshotTaker: null,
    searchSync: null,
  };

  try {
    // Link checker worker - runs daily to check if links are still valid
    workers.linkChecker = new Worker('linkChecker', linkCheckerProcessor, {
      connection: redisClient,
    });
    workers.linkChecker.on('completed', (job) => {
      logger.info({ jobId: job.id }, 'Link checker job completed');
    });
    workers.linkChecker.on('failed', (job, error) => {
      logger.error({ jobId: job?.id, error }, 'Link checker job failed');
    });

    // Feed builder worker - regenerates RSS/Atom/JSON feeds
    workers.feedBuilder = new Worker('feedBuilder', feedBuilderProcessor, {
      connection: redisClient,
    });
    workers.feedBuilder.on('completed', (job) => {
      logger.info({ jobId: job.id }, 'Feed builder job completed');
    });
    workers.feedBuilder.on('failed', (job, error) => {
      logger.error({ jobId: job?.id, error }, 'Feed builder job failed');
    });

    // Snapshot taker worker - takes snapshots of web pages
    workers.snapshotTaker = new Worker('snapshotTaker', snapshotTakerProcessor, {
      connection: redisClient,
    });
    workers.snapshotTaker.on('completed', (job) => {
      logger.info({ jobId: job.id }, 'Snapshot taker job completed');
    });
    workers.snapshotTaker.on('failed', (job, error) => {
      logger.error({ jobId: job?.id, error }, 'Snapshot taker job failed');
    });

    // Search sync worker - synchronizes posts with Algolia
    workers.searchSync = new Worker('searchSync', searchSyncProcessor, {
      connection: redisClient,
    });
    workers.searchSync.on('completed', (job) => {
      logger.info({ jobId: job.id }, 'Search sync job completed');
    });
    workers.searchSync.on('failed', (job, error) => {
      logger.error({ jobId: job?.id, error }, 'Search sync job failed');
    });

    // Schedule recurring jobs
    scheduleJobs();

    logger.info('All workers started successfully');
    return workers;
  } catch (error) {
    logger.error({ error }, 'Failed to start workers');
    
    // Attempt to clean up any workers that did start
    for (const [name, worker] of Object.entries(workers)) {
      if (worker) {
        logger.info(`Closing worker: ${name}`);
        worker.close().catch((err) => {
          logger.error({ error: err }, `Error closing worker: ${name}`);
        });
      }
    }
    
    return null;
  }
}

// Function to schedule recurring jobs
async function scheduleJobs() {
  if (!redisClient) {
    return;
  }

  try {
    // Link checker queue
    const linkCheckerQueue = new Queue('linkChecker', { connection: redisClient });
    await linkCheckerQueue.add(
      'dailyCheck',
      { timestamp: new Date().toISOString() },
      {
        repeat: {
          pattern: '0 4 * * *', // Every day at 4:00 UTC
        },
        removeOnComplete: true,
        removeOnFail: 10, // Keep last 10 failed jobs
      }
    );

    // Feed builder queue
    const feedBuilderQueue = new Queue('feedBuilder', { connection: redisClient });
    await feedBuilderQueue.add(
      'rebuildFeeds',
      { timestamp: new Date().toISOString() },
      {
        repeat: {
          pattern: '*/15 * * * *', // Every 15 minutes
        },
        removeOnComplete: true,
        removeOnFail: 10,
      }
    );

    // Search sync queue
    const searchSyncQueue = new Queue('searchSync', { connection: redisClient });
    await searchSyncQueue.add(
      'syncPosts',
      { timestamp: new Date().toISOString() },
      {
        repeat: {
          pattern: '0 * * * *', // Every hour
        },
        removeOnComplete: true,
        removeOnFail: 10,
      }
    );

    logger.info('Recurring jobs scheduled successfully');
  } catch (error) {
    logger.error({ error }, 'Failed to schedule recurring jobs');
  }
}

// Function to gracefully stop all workers
export async function stopWorkers(workers: WorkersType | null): Promise<void> {
  if (!workers) {
    return;
  }

  const closePromises = Object.entries(workers)
    .filter(([_, worker]) => worker !== null)
    .map(async ([name, worker]) => {
      try {
        logger.info(`Closing worker: ${name}`);
        await worker!.close();
      } catch (error) {
        logger.error({ error }, `Error closing worker: ${name}`);
      }
    });

  await Promise.all(closePromises);
  logger.info('All workers stopped');
}

// If this file is run directly, start the workers
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const workers = startWorkers();
  
  // Handle process termination
  process.on('SIGTERM', async () => {
    logger.info('Received SIGTERM, shutting down workers');
    await stopWorkers(workers);
    process.exit(0);
  });
  
  process.on('SIGINT', async () => {
    logger.info('Received SIGINT, shutting down workers');
    await stopWorkers(workers);
    process.exit(0);
  });
}
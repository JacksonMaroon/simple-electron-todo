import { inferAsyncReturnType } from '@trpc/server';
import { FastifyRequest, FastifyReply } from 'fastify';
import { JwtPayload, verifyToken } from '../utils/auth.js';
import { prisma } from '../lib/prisma.js';

// Context interface
export interface Context {
  req: FastifyRequest;
  res: FastifyReply;
  prisma: typeof prisma;
  user?: {
    id: string;
    email: string;
    role: string;
  };
}

// Create tRPC context
export async function createContext({
  request,
  reply,
}: {
  request: FastifyRequest;
  reply: FastifyReply;
}): Promise<Context> {
  const authHeader = request.headers.authorization;
  const token = authHeader?.replace('Bearer ', '');
  
  let user = undefined;

  // Verify JWT token if provided
  if (token) {
    try {
      const payload = verifyToken(token) as JwtPayload;
      
      // Only accept access tokens, not refresh tokens
      if (payload.type === 'access') {
        user = {
          id: payload.userId,
          email: payload.email,
          role: payload.role,
        };
      }
    } catch (error) {
      // Token verification failed, user will be undefined
      // We don't throw here to allow non-authenticated endpoints to work
    }
  }

  return {
    req: request,
    res: reply,
    prisma,
    user,
  };
}

// Type for context to be used in routers
export type TrpcContext = inferAsyncReturnType<typeof createContext>;
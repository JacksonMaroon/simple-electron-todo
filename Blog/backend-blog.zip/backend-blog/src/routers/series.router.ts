import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { adminProcedure, publicProcedure, router } from './trpc.js';

// Define validation schemas
const seriesSchema = z.object({
  title: z.string().min(1).max(100),
  description: z.string().optional(),
  order: z.array(z.string()).optional(),
});

const seriesUpdateSchema = seriesSchema.partial().extend({
  id: z.string(),
});

// Series router for CRUD operations
export const seriesRouter = router({
  // Get all series
  list: publicProcedure
    .query(async ({ ctx }) => {
      const { prisma } = ctx;

      const seriesList = await prisma.series.findMany({
        orderBy: {
          title: 'asc',
        },
      });

      return { series: seriesList };
    }),

  // Get a single series with its posts
  getById: publicProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { user } = ctx;
      const { id } = input;

      const series = await prisma.series.findUnique({
        where: { id },
      });

      if (!series) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Series not found',
        });
      }

      // Parse the order JSON
      const orderArray = series.order ? JSON.parse(String(series.order)) : [];

      // Build the query for posts
      const where: any = {
        seriesId: id,
        deleted: false,
      };

      // If not admin, only show published posts
      if (!user || user.role !== 'ADMIN') {
        where.status = 'PUBLISHED';
      }

      // Get posts in this series
      const posts = await prisma.post.findMany({
        where,
        select: {
          id: true,
          title: true,
          slug: true,
          summary: true,
          status: true,
          publishedAt: true,
          updatedAt: true,
        },
      });

      // Sort posts according to the order array
      const sortedPosts = orderArray.length
        ? orderArray
            .map((id: string) => posts.find((post) => post.id === id))
            .filter(Boolean)
        : posts;

      return {
        ...series,
        posts: sortedPosts,
      };
    }),

  // Create a new series (admin only)
  create: adminProcedure
    .input(seriesSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { title, description, order } = input;

      // Check if series with title already exists
      const existingSeries = await prisma.series.findFirst({
        where: {
          title: {
            equals: title,
            mode: 'insensitive', // Case insensitive comparison
          },
        },
      });

      if (existingSeries) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'Series with this title already exists',
        });
      }

      // Create series
      const series = await prisma.series.create({
        data: {
          title,
          description,
          order: order ? JSON.stringify(order) : null,
        },
      });

      return series;
    }),

  // Update an existing series (admin only)
  update: adminProcedure
    .input(seriesUpdateSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id, title, description, order } = input;

      // Check if series exists
      const existingSeries = await prisma.series.findUnique({
        where: { id },
      });

      if (!existingSeries) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Series not found',
        });
      }

      // If changing title, check if already exists
      if (title && title !== existingSeries.title) {
        const titleExists = await prisma.series.findFirst({
          where: {
            title: {
              equals: title,
              mode: 'insensitive', // Case insensitive comparison
            },
            id: {
              not: id,
            },
          },
        });

        if (titleExists) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'Series with this title already exists',
          });
        }
      }

      // Update series
      const series = await prisma.series.update({
        where: { id },
        data: {
          title,
          description,
          order: order ? JSON.stringify(order) : undefined,
        },
      });

      return series;
    }),

  // Delete a series (admin only)
  delete: adminProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { id } = input;

      // Check if series exists
      const existingSeries = await prisma.series.findUnique({
        where: { id },
      });

      if (!existingSeries) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Series not found',
        });
      }

      // Update all posts in this series to remove the series reference
      await prisma.post.updateMany({
        where: { seriesId: id },
        data: { seriesId: null },
      });

      // Delete series
      await prisma.series.delete({
        where: { id },
      });

      return { success: true };
    }),
});
import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { adminProcedure, authenticatedProcedure, publicProcedure, router } from './trpc.js';
import { prisma } from '../lib/prisma.js';

// Define validation schemas
const postSchema = z.object({
  title: z.string().min(1).max(255),
  slug: z.string().min(1).max(255).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  contentMDX: z.string().min(1),
  summary: z.string().optional(),
  status: z.enum(['DRAFT', 'PUBLISHED']).default('DRAFT'),
  publishedAt: z.date().optional(),
  tags: z.array(z.string()).optional(),
  seriesId: z.string().optional(),
});

const postUpdateSchema = postSchema.partial().extend({
  id: z.string(),
});

const postFilterSchema = z.object({
  tag: z.string().optional(),
  series: z.string().optional(),
  status: z.enum(['DRAFT', 'PUBLISHED']).optional(),
  search: z.string().optional(),
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(1).max(100).default(10),
});

// Posts router for CRUD operations
export const postsRouter = router({
  // Get a list of posts with optional filtering
  list: publicProcedure
    .input(postFilterSchema)
    .query(async ({ ctx, input }) => {
      const { tag, series, status, search, page, limit } = input;
      const skip = (page - 1) * limit;

      // Build filters
      const where: any = {
        deleted: false,
      };

      // If not authenticated or not admin, only show published posts
      if (!ctx.user || ctx.user.role !== 'ADMIN') {
        where.status = 'PUBLISHED';
      } else if (status) {
        where.status = status;
      }

      // Filter by tag if provided
      if (tag) {
        where.tags = {
          some: {
            tag: {
              name: tag,
            },
          },
        };
      }

      // Filter by series if provided
      if (series) {
        where.series = {
          title: series,
        };
      }

      // Filter by search term if provided
      if (search) {
        where.OR = [
          { title: { contains: search } },
          { contentMDX: { contains: search } },
        ];
      }

      // Get posts with count
      const [posts, total] = await Promise.all([
        prisma.post.findMany({
          where,
          include: {
            tags: {
              include: {
                tag: true,
              },
            },
            series: {
              select: {
                id: true,
                title: true,
              },
            },
          },
          orderBy: {
            publishedAt: 'desc',
          },
          skip,
          take: limit,
        }),
        prisma.post.count({ where }),
      ]);

      // Format the response
      return {
        posts: posts.map((post) => ({
          ...post,
          tags: post.tags.map((t) => t.tag),
        })),
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit),
        },
      };
    }),

  // Get a single post by slug
  getBySlug: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ ctx, input }) => {
      const { slug } = input;
      const { user } = ctx;

      // Build the query
      const where: any = {
        slug,
        deleted: false,
      };

      // If not authenticated or not admin, only show published posts
      if (!user || user.role !== 'ADMIN') {
        where.status = 'PUBLISHED';
      }

      // Get the post
      const post = await prisma.post.findFirst({
        where,
        include: {
          tags: {
            include: {
              tag: true,
            },
          },
          series: {
            select: {
              id: true,
              title: true,
              order: true,
            },
          },
        },
      });

      if (!post) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Post not found',
        });
      }

      // Format the response
      return {
        ...post,
        tags: post.tags.map((t) => t.tag),
      };
    }),

  // Create a new post (admin only)
  create: adminProcedure
    .input(postSchema)
    .mutation(async ({ ctx, input }) => {
      const { tags, ...postData } = input;
      const { prisma } = ctx;

      // Check if slug is already in use
      const existingPost = await prisma.post.findUnique({
        where: { slug: input.slug },
      });

      if (existingPost) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'Slug already in use',
        });
      }

      // Create post
      const post = await prisma.post.create({
        data: {
          ...postData,
          publishedAt: input.status === 'PUBLISHED' ? new Date() : undefined,
        },
      });

      // Connect tags if provided
      if (tags && tags.length > 0) {
        await Promise.all(
          tags.map(async (tagId) => {
            await prisma.postTag.create({
              data: {
                postId: post.id,
                tagId,
              },
            });
          })
        );
      }

      // If part of a series, update the series order
      if (postData.seriesId) {
        const series = await prisma.series.findUnique({
          where: { id: postData.seriesId },
        });

        if (series) {
          const orderArray = series.order ? JSON.parse(String(series.order)) : [];
          orderArray.push(post.id);

          await prisma.series.update({
            where: { id: series.id },
            data: { order: JSON.stringify(orderArray) },
          });
        }
      }

      return post;
    }),

  // Update an existing post (admin only)
  update: adminProcedure
    .input(postUpdateSchema)
    .mutation(async ({ ctx, input }) => {
      const { id, tags, ...updateData } = input;
      const { prisma } = ctx;

      // Check if post exists
      const existingPost = await prisma.post.findUnique({
        where: { id },
        include: {
          tags: true,
        },
      });

      if (!existingPost) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Post not found',
        });
      }

      // Check if slug changed and is already in use
      if (updateData.slug && updateData.slug !== existingPost.slug) {
        const slugExists = await prisma.post.findUnique({
          where: { slug: updateData.slug },
        });

        if (slugExists && slugExists.id !== id) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'Slug already in use',
          });
        }
      }

      // Set publishedAt if status changed to PUBLISHED
      if (
        updateData.status === 'PUBLISHED' &&
        existingPost.status !== 'PUBLISHED'
      ) {
        updateData.publishedAt = new Date();
      }

      // Update post
      const post = await prisma.post.update({
        where: { id },
        data: updateData,
      });

      // Update tags if provided
      if (tags) {
        // Delete existing tags
        await prisma.postTag.deleteMany({
          where: { postId: id },
        });

        // Create new tags
        await Promise.all(
          tags.map(async (tagId) => {
            await prisma.postTag.create({
              data: {
                postId: post.id,
                tagId,
              },
            });
          })
        );
      }

      // If series changed, update series order
      if (
        updateData.seriesId !== undefined &&
        updateData.seriesId !== existingPost.seriesId
      ) {
        // Remove from old series
        if (existingPost.seriesId) {
          const oldSeries = await prisma.series.findUnique({
            where: { id: existingPost.seriesId },
          });

          if (oldSeries && oldSeries.order) {
            const orderArray = JSON.parse(String(oldSeries.order));
            const newOrderArray = orderArray.filter((postId: string) => postId !== id);

            await prisma.series.update({
              where: { id: oldSeries.id },
              data: { order: JSON.stringify(newOrderArray) },
            });
          }
        }

        // Add to new series
        if (updateData.seriesId) {
          const newSeries = await prisma.series.findUnique({
            where: { id: updateData.seriesId },
          });

          if (newSeries) {
            const orderArray = newSeries.order ? JSON.parse(String(newSeries.order)) : [];
            orderArray.push(post.id);

            await prisma.series.update({
              where: { id: newSeries.id },
              data: { order: JSON.stringify(orderArray) },
            });
          }
        }
      }

      return post;
    }),

  // Delete a post (admin only)
  delete: adminProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { id } = input;
      const { prisma } = ctx;

      // Check if post exists
      const existingPost = await prisma.post.findUnique({
        where: { id },
      });

      if (!existingPost) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Post not found',
        });
      }

      // Soft delete the post
      const post = await prisma.post.update({
        where: { id },
        data: { deleted: true },
      });

      // Remove from series if part of one
      if (existingPost.seriesId) {
        const series = await prisma.series.findUnique({
          where: { id: existingPost.seriesId },
        });

        if (series && series.order) {
          const orderArray = JSON.parse(String(series.order));
          const newOrderArray = orderArray.filter((postId: string) => postId !== id);

          await prisma.series.update({
            where: { id: series.id },
            data: { order: JSON.stringify(newOrderArray) },
          });
        }
      }

      return post;
    }),
});
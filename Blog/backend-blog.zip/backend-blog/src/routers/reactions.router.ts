import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { publicProcedure, router } from './trpc.js';
import { createHash } from 'crypto';

// Define validation schemas
const addReactionSchema = z.object({
  postId: z.string(),
  type: z.enum(['CLAP', 'STAR', 'LIKE']),
});

// Reactions router for managing user reactions to posts
export const reactionsRouter = router({
  // Add a reaction (idempotent by IP + cookie)
  add: publicProcedure
    .input(addReactionSchema)
    .mutation(async ({ ctx, input }) => {
      const { prisma, req } = ctx;
      const { postId, type } = input;

      // Check if post exists
      const post = await prisma.post.findUnique({
        where: { id: postId },
      });

      if (!post) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Post not found',
        });
      }

      // Generate a hash of the IP address for anonymity
      // Combined with a browser cookie or fingerprint to prevent multiple reactions
      const ip = req.ip || req.socket.remoteAddress || '0.0.0.0';
      const hasher = createHash('sha256');
      hasher.update(ip);
      
      // You might also want to include a unique identifier from cookies if available
      const cookieId = req.cookies.reactId || '';
      if (cookieId) {
        hasher.update(cookieId);
      }
      
      const userIpHash = hasher.digest('hex');

      try {
        // Create the reaction (upsert to make it idempotent)
        await prisma.reaction.upsert({
          where: {
            postId_type_userIpHash: {
              postId,
              type,
              userIpHash,
            },
          },
          update: {}, // No updates needed, just ensure it exists
          create: {
            postId,
            type,
            userIpHash,
          },
        });

        // Count reactions by type
        const counts = await prisma.reaction.groupBy({
          by: ['type'],
          where: { postId },
          _count: true,
        });

        // Format the response
        const formatted = {
          CLAP: 0,
          STAR: 0,
          LIKE: 0,
        };

        counts.forEach((count) => {
          formatted[count.type] = count._count;
        });

        return {
          success: true,
          counts: formatted,
        };
      } catch (error) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to save reaction',
          cause: error,
        });
      }
    }),

  // Get reaction counts for a post
  count: publicProcedure
    .input(z.object({ postId: z.string() }))
    .query(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { postId } = input;

      // Check if post exists
      const post = await prisma.post.findUnique({
        where: { id: postId },
      });

      if (!post) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Post not found',
        });
      }

      // Count reactions by type
      const counts = await prisma.reaction.groupBy({
        by: ['type'],
        where: { postId },
        _count: true,
      });

      // Format the response
      const formatted = {
        CLAP: 0,
        STAR: 0,
        LIKE: 0,
      };

      counts.forEach((count) => {
        formatted[count.type] = count._count;
      });

      return formatted;
    }),

  // Get top posts by reaction count
  topPosts: publicProcedure
    .input(
      z.object({
        type: z.enum(['CLAP', 'STAR', 'LIKE']).optional(),
        limit: z.number().int().min(1).max(50).default(10),
      })
    )
    .query(async ({ ctx, input }) => {
      const { prisma } = ctx;
      const { type, limit } = input;

      // Query params
      const where: any = {
        post: {
          status: 'PUBLISHED',
          deleted: false,
        },
      };

      if (type) {
        where.type = type;
      }

      // First, get reaction counts
      const reactionCounts = await prisma.reaction.groupBy({
        by: ['postId'],
        where,
        _count: true,
        orderBy: {
          _count: {
            postId: 'desc',
          },
        },
        take: limit,
      });

      // Get the actual posts
      const postIds = reactionCounts.map((r) => r.postId);
      const posts = await prisma.post.findMany({
        where: {
          id: { in: postIds },
        },
        select: {
          id: true,
          title: true,
          slug: true,
          summary: true,
          publishedAt: true,
        },
      });

      // Sort posts by reaction count
      const sortedPosts = postIds.map((id) => posts.find((p) => p.id === id)).filter(Boolean);

      return {
        posts: sortedPosts,
      };
    }),
});
import { TRPCError } from '@trpc/server';
import { FastifyReply } from 'fastify';

// HTTP error codes
export enum HttpStatus {
  BAD_REQUEST = 400,
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  NOT_FOUND = 404,
  METHOD_NOT_ALLOWED = 405,
  CONFLICT = 409,
  UNPROCESSABLE_ENTITY = 422,
  INTERNAL_SERVER_ERROR = 500,
  SERVICE_UNAVAILABLE = 503,
}

// RFC 7807 Problem Details interface
export interface ProblemDetails {
  type: string;
  title: string;
  status: number;
  detail?: string;
  instance?: string;
  errors?: Record<string, string[]>;
}

// Convert a TRPC error to a Problem Details response
export function trpcErrorToProblemDetails(error: TRPCError): ProblemDetails {
  const problem: ProblemDetails = {
    type: `https://example.com/errors/${error.code.toLowerCase()}`,
    title: error.message,
    status: mapTRPCErrorCodeToHttpStatus(error.code),
  };

  if (error.cause) {
    problem.detail = error.cause instanceof Error 
      ? error.cause.message 
      : String(error.cause);
  }

  return problem;
}

// Map TRPC error codes to HTTP status codes
function mapTRPCErrorCodeToHttpStatus(code: string): number {
  switch (code) {
    case 'BAD_REQUEST':
      return HttpStatus.BAD_REQUEST;
    case 'UNAUTHORIZED':
      return HttpStatus.UNAUTHORIZED;
    case 'FORBIDDEN':
      return HttpStatus.FORBIDDEN;
    case 'NOT_FOUND':
      return HttpStatus.NOT_FOUND;
    case 'METHOD_NOT_SUPPORTED':
      return HttpStatus.METHOD_NOT_ALLOWED;
    case 'TIMEOUT':
    case 'INTERNAL_SERVER_ERROR':
      return HttpStatus.INTERNAL_SERVER_ERROR;
    case 'CONFLICT':
      return HttpStatus.CONFLICT;
    case 'PRECONDITION_FAILED':
    case 'PARSE_ERROR':
    case 'BAD_RESPONSE':
      return HttpStatus.UNPROCESSABLE_ENTITY;
    default:
      return HttpStatus.INTERNAL_SERVER_ERROR;
  }
}

// Send a Problem Details response
export function sendProblemDetails(reply: FastifyReply, problem: ProblemDetails): FastifyReply {
  return reply
    .status(problem.status)
    .header('Content-Type', 'application/problem+json')
    .send(problem);
}

// Create a Problem Details object
export function createProblemDetails(
  title: string,
  status: HttpStatus,
  detail?: string,
  type?: string,
  instance?: string,
  errors?: Record<string, string[]>
): ProblemDetails {
  return {
    type: type || `https://example.com/errors/${status}`,
    title,
    status,
    detail,
    instance,
    errors,
  };
}
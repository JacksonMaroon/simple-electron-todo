import pino from 'pino';
import { config, isDev } from '../config.js';

// Create logger instance with appropriate settings based on environment
export const logger = pino({
  level: config.LOG_LEVEL,
  transport: isDev
    ? {
        target: 'pino-pretty',
        options: {
          colorize: true,
          translateTime: 'SYS:standard',
          ignore: 'pid,hostname',
        },
      }
    : undefined,
  // Add additional context to all logs
  base: {
    env: config.NODE_ENV,
  },
});

export default logger;
import Redis from 'ioredis';
import { config, isDev } from '../config.js';

// Create Redis connection
export function createRedisClient() {
  if (!config.REDIS_URL) {
    if (isDev) {
      console.warn('REDIS_URL not set. Using default localhost connection.');
      return new Redis();
    }
    throw new Error('REDIS_URL must be set in production environment');
  }

  const client = new Redis(config.REDIS_URL, {
    maxRetriesPerRequest: 3,
    enableReadyCheck: true,
  });

  client.on('error', (err) => {
    console.error('Redis connection error:', err);
  });

  return client;
}

// Create a shared Redis client or null if Redis is not available
export let redisClient: Redis | null = null;

try {
  redisClient = createRedisClient();
} catch (error) {
  console.warn('Redis client not initialized:', error);
}

export default redisClient;
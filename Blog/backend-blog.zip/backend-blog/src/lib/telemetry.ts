import { NodeSDK } from '@opentelemetry/sdk-node';
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';
import { Resource } from '@opentelemetry/resources';
import { SemanticResourceAttributes } from '@opentelemetry/semantic-conventions';
import { config, isTest } from '../config.js';
import { logger } from './logger.js';

// Configure OpenTelemetry SDK
export const createTelemetryProvider = () => {
  // Skip telemetry in test environment
  if (isTest) {
    return null;
  }

  try {
    if (!config.OTEL_EXPORTER_OTLP_ENDPOINT) {
      logger.warn('OpenTelemetry endpoint not configured. Telemetry will not be exported.');
      return null;
    }

    const traceExporter = new OTLPTraceExporter({
      url: config.OTEL_EXPORTER_OTLP_ENDPOINT + '/v1/traces',
    });

    // Create and configure SDK
    const sdk = new NodeSDK({
      resource: new Resource({
        [SemanticResourceAttributes.SERVICE_NAME]: 'blog-backend',
        [SemanticResourceAttributes.SERVICE_VERSION]: '1.0.0',
        [SemanticResourceAttributes.DEPLOYMENT_ENVIRONMENT]: config.NODE_ENV,
      }),
      traceExporter,
      instrumentations: [
        getNodeAutoInstrumentations({
          '@opentelemetry/instrumentation-fs': { enabled: false },
          '@opentelemetry/instrumentation-http': { enabled: true },
          '@opentelemetry/instrumentation-express': { enabled: true },
          '@opentelemetry/instrumentation-fastify': { enabled: true },
          '@opentelemetry/instrumentation-redis': { enabled: true },
        }),
      ],
    });

    // Initialize the SDK
    sdk.start();

    logger.info('OpenTelemetry initialized');
    
    // Handle shutdown
    process.on('SIGTERM', () => {
      sdk
        .shutdown()
        .then(() => logger.info('OpenTelemetry SDK shut down'))
        .catch((error) => logger.error('Error shutting down OpenTelemetry SDK', error))
        .finally(() => process.exit(0));
    });

    return sdk;
  } catch (error) {
    logger.error('Failed to initialize OpenTelemetry', error);
    return null;
  }
};

export default createTelemetryProvider;
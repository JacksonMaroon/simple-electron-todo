#!/bin/bash
# One-liner installer script for the blog backend

# Create dirs if they don't exist
mkdir -p prisma
mkdir -p src/{server,routers,workers,lib,utils}

# Initialize npm if package.json doesn't exist
if [ ! -f package.json ]; then
  npm init -y
fi

# Install dependencies
npm install --save fastify @fastify/cors @fastify/helmet @fastify/rate-limit @fastify/static
npm install --save @trpc/server zod
npm install --save @prisma/client bcrypt jsonwebtoken
npm install --save bullmq ioredis
npm install --save @opentelemetry/sdk-node @opentelemetry/auto-instrumentations-node @opentelemetry/exporter-trace-otlp-http
npm install --save algoliasearch pino pino-pretty 

# Install dev dependencies
npm install --save-dev typescript @types/node ts-node ts-node-dev
npm install --save-dev prisma vitest supertest @types/supertest
npm install --save-dev @types/bcrypt @types/jsonwebtoken eslint

# Initialize TypeScript config if it doesn't exist
if [ ! -f tsconfig.json ]; then
  npx tsc --init
fi

# Initialize SQLite database if it doesn't exist
if [ ! -f prisma/dev.db ]; then
  npx prisma migrate dev --name init
fi

# Print success message
echo "Environment successfully bootstrapped!"
echo "Run 'npm run dev' to start the development server"
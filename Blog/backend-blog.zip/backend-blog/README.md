# Gwern-Inspired Blog Backend

A robust backend and infrastructure for a personal blog, inspired by Gwern's website. This project provides a complete API server, database models, workers, and deployment configurations for running a feature-rich blog.

## Tech Stack

- **Node 20 + TypeScript (ESM)** running on Fastify
- **Prisma ORM** over SQLite (dev) and PostgreSQL (prod)
- **tRPC** for type-safe API routes
- **Zod** schemas for runtime validation
- **Redis** for job-queue and caching
- **BullMQ** worker for periodic tasks (link-rot checks, feed rebuilds)
- **Algolia** search indexer
- **JWT** auth with refresh rotation
- **OpenTelemetry** traces + pino-pretty logs
- **Docker-Compose** for local orchestration

## Quick Start

### One-Line Setup

```bash
curl -fsSL https://raw.githubusercontent.com/yourusername/blog-backend/main/install.sh | bash
```

### Manual Setup

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Set up your environment variables (copy `.env.example` to `.env`)
4. Initialize the database:
   ```bash
   npm run db:migrate
   npm run db:seed
   ```
5. Start the development server:
   ```bash
   npm run dev
   ```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Server port | 3000 |
| `HOST` | Server host | localhost |
| `NODE_ENV` | Environment | development |
| `DATABASE_URL` | Database connection string | file:./dev.db |
| `JWT_SECRET` | Secret for JWT tokens | (required) |
| `JWT_EXPIRES_IN` | Access token expiry | 1d |
| `JWT_REFRESH_EXPIRES_IN` | Refresh token expiry | 7d |
| `REDIS_URL` | Redis connection string | redis://localhost:6379 |
| `ALGOLIA_APP_ID` | Algolia application ID | (optional) |
| `ALGOLIA_API_KEY` | Algolia API key | (optional) |
| `ALGOLIA_INDEX_NAME` | Algolia index name | blog_posts |

## API Endpoints

The API is built with tRPC, providing fully type-safe endpoints. Here's an overview of available routers:

- **auth**: signup, login, refresh, forgot-password
- **posts**: list, getBySlug, create/update/delete
- **comments**: add, list, moderate
- **tags** & **series**: CRUD endpoints
- **search**: proxy query to Algolia
- **feeds**: regenerate RSS/Atom/JSON
- **links**: markDead, snapshotLink
- **reactions**: add, count

### Example: Fetching Posts

```typescript
// Client-side
fetch('/api/trpc/posts.list')
  .then(res => res.json())
  .then(data => console.log(data.result.data.posts));
```

### Authentication Flow

1. **Login**
   ```typescript
   const response = await fetch('/api/trpc/auth.login', {
     method: 'POST',
     headers: { 'Content-Type': 'application/json' },
     body: JSON.stringify({
       json: {
         email: 'user@example.com',
         password: 'password123'
       }
     })
   });
   const data = await response.json();
   const { accessToken, refreshToken } = data.result.data;
   ```

2. **Use Access Token**
   ```typescript
   fetch('/api/trpc/posts.create', {
     method: 'POST',
     headers: {
       'Content-Type': 'application/json',
       'Authorization': `Bearer ${accessToken}`
     },
     body: JSON.stringify({
       json: {
         title: 'My New Post',
         slug: 'my-new-post',
         contentMDX: '# Hello World',
         status: 'DRAFT'
       }
     })
   });
   ```

3. **Refresh Token**
   ```typescript
   const response = await fetch('/api/trpc/auth.refresh', {
     method: 'POST',
     headers: { 'Content-Type': 'application/json' },
     body: JSON.stringify({
       json: { refreshToken }
     })
   });
   const data = await response.json();
   const { accessToken: newAccessToken, refreshToken: newRefreshToken } = data.result.data;
   ```

## Background Workers

The system includes several background workers via BullMQ:

- **linkChecker**: Daily job to check if outbound links are still valid
- **feedBuilder**: Regenerates RSS, Atom, and JSON feeds every 15 minutes
- **snapshotTaker**: Takes snapshots of web pages (HTML, PDF, PNG)
- **searchSync**: Synchronizes posts with Algolia search index

## Deployment

### Docker Compose

For local development and testing:

```bash
docker-compose up
```

### Fly.io

Deploy to Fly.io:

```bash
fly launch
```

### Vercel

Deploy the API to Vercel:

```bash
vercel
```

## Integrating with a Frontend

This backend is designed to work with any frontend. Here are some integration points:

### Next.js Example

```typescript
// Create a tRPC client
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend-blog/src/routers';

const client = createTRPCProxyClient<AppRouter>({
  links: [
    httpBatchLink({
      url: 'http://localhost:3000/api/trpc',
    }),
  ],
});

// Use in a component
async function Posts() {
  const posts = await client.posts.list.query();
  
  return (
    <div>
      <h1>Blog Posts</h1>
      <ul>
        {posts.posts.map(post => (
          <li key={post.id}>
            <a href={`/posts/${post.slug}`}>{post.title}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}
```

## Data Model

### Core Entities
- **User**: Authentication and authorization
- **Post**: Blog posts with MDX content
- **Tag**: Categories for posts
- **Series**: Groups of related posts
- **Comment**: User comments on posts
- **OutboundLink**: Links to external resources
- **Snapshot**: Archives of web pages
- **Reaction**: User interactions with posts

## Scripts and Utilities

- `npm run dev`: Start development server
- `npm run build`: Build for production
- `npm start`: Start production server
- `npm run db:migrate`: Run database migrations
- `npm run db:seed`: Seed the database with demo data
- `npm test`: Run tests
- `npm run worker`: Run background workers separately

## Testing

Run the test suite:

```bash
npm test
```

Check out `scripts/demo.http` for example API requests that can be used with REST Client for VS Code.

## License

MIT
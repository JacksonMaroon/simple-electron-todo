import { describe, it, expect, beforeAll } from 'vitest';
import { app, prisma, generateTestToken } from './setup';
import { AppRouter } from '../src/routers';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import superjson from 'superjson';

// Create a trpc client for testing with auth
const token = generateTestToken('test-admin-id');
const authedClient = createTRPCProxyClient<AppRouter>({
  links: [
    httpBatchLink({
      url: 'http://localhost:3000/api/trpc',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      fetch: async (url, options) => {
        const response = await app.inject({
          method: options?.method || 'GET',
          url: url.toString(),
          headers: options?.headers as Record<string, string>,
          payload: options?.body,
        });

        return {
          ok: response.statusCode >= 200 && response.statusCode < 300,
          status: response.statusCode,
          headers: new Headers(response.headers as Record<string, string>),
          json: async () => JSON.parse(response.payload),
          text: async () => response.payload,
        } as Response;
      },
    }),
  ],
  transformer: superjson,
});

// Create a client without auth
const publicClient = createTRPCProxyClient<AppRouter>({
  links: [
    httpBatchLink({
      url: 'http://localhost:3000/api/trpc',
      fetch: async (url, options) => {
        const response = await app.inject({
          method: options?.method || 'GET',
          url: url.toString(),
          headers: options?.headers as Record<string, string>,
          payload: options?.body,
        });

        return {
          ok: response.statusCode >= 200 && response.statusCode < 300,
          status: response.statusCode,
          headers: new Headers(response.headers as Record<string, string>),
          json: async () => JSON.parse(response.payload),
          text: async () => response.payload,
        } as Response;
      },
    }),
  ],
  transformer: superjson,
});

describe('Posts Router', () => {
  let testPostId: string;
  let testPostSlug: string;

  beforeAll(async () => {
    // Create a test post
    const post = await prisma.post.create({
      data: {
        title: 'Test Post',
        slug: 'test-post',
        contentMDX: '# Test Post\n\nThis is a test post.',
        status: 'PUBLISHED',
        publishedAt: new Date(),
      },
    });
    
    testPostId = post.id;
    testPostSlug = post.slug;

    // Create a draft post
    await prisma.post.create({
      data: {
        title: 'Draft Post',
        slug: 'draft-post',
        contentMDX: '# Draft Post\n\nThis is a draft post.',
        status: 'DRAFT',
      },
    });
  });

  it('should list published posts for public users', async () => {
    const result = await publicClient.posts.list.query({
      page: 1,
      limit: 10,
    });

    expect(result.posts).toHaveLength(1); // Only the published post
    expect(result.posts[0].title).toBe('Test Post');
    expect(result.pagination.total).toBe(1);
  });

  it('should list all posts for admin users', async () => {
    const result = await authedClient.posts.list.query({
      page: 1,
      limit: 10,
    });

    expect(result.posts).toHaveLength(2); // Both published and draft
    expect(result.pagination.total).toBe(2);
  });

  it('should get a post by slug', async () => {
    const result = await publicClient.posts.getBySlug.query({
      slug: testPostSlug,
    });

    expect(result.title).toBe('Test Post');
    expect(result.contentMDX).toContain('This is a test post.');
  });

  it('should create a new post', async () => {
    const result = await authedClient.posts.create.mutate({
      title: 'New Post',
      slug: 'new-post',
      contentMDX: '# New Post\n\nThis is a new post created in a test.',
      status: 'DRAFT',
    });

    expect(result.title).toBe('New Post');
    expect(result.slug).toBe('new-post');
    expect(result.status).toBe('DRAFT');
  });

  it('should update an existing post', async () => {
    const result = await authedClient.posts.update.mutate({
      id: testPostId,
      title: 'Updated Post',
    });

    expect(result.title).toBe('Updated Post');
    expect(result.id).toBe(testPostId);
  });

  it('should soft delete a post', async () => {
    const result = await authedClient.posts.delete.mutate({
      id: testPostId,
    });

    expect(result.deleted).toBe(true);
    expect(result.id).toBe(testPostId);

    // Verify the post doesn't appear in results
    const listResult = await publicClient.posts.list.query({
      page: 1,
      limit: 10,
    });

    const deletedPost = listResult.posts.find(p => p.id === testPostId);
    expect(deletedPost).toBeUndefined();
  });
});